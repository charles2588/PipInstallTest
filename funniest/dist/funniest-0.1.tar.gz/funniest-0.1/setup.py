from setuptools import setup

setup(name='funniest',
      version='0.1',
      description='The funniest joke in the world',
      url='http://github.com/charles2588/funniest',
      author='Charles Gomes',
      author_email='charles2588@gmail.com',
      license='MIT',
      packages=['funniest'],
      zip_safe=False)
