def joke():
    return (u'Hear about the new restaurant called karma? There’s no menu: You get what you deserve.')
